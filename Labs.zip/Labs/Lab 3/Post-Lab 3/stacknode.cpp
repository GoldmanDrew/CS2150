/*
Drew Goldman
dag5wd
9/23/2020
stacknode.cpp
*/

#include <iostream> 
#include <iterator> 
#include <string>
#include "stacknode.h"
using namespace std;

stacknode::stacknode() {
  next = NULL;
  e = 0;
}
