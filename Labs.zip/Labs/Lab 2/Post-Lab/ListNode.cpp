/*
Drew Goldman
dag5wd
9/15/2020
ListNode.cpp
*/

#include <iostream>
#include <string>
#include <cctype>
#include "ListNode.h"
using namespace std;


ListNode::ListNode() {
  value = 0;
  next = NULL;
  previous = NULL;
}
